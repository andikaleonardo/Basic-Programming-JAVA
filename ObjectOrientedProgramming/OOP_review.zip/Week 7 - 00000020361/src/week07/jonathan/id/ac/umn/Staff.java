package week07.jonathan.id.ac.umn;

public class Staff extends Orang {
	String nik;

	public Staff() {
		//super();
		// TODO Auto-generated constructor stub
	}

	public Staff(String nama, String tmptlahir, String tanggalLahir, String nik) {
		super(nama, tmptlahir, tanggalLahir);
		this.nik = nik;
		// TODO Auto-generated constructor stub
	}
	
	
}
